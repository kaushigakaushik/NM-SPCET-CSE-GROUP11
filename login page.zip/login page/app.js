import React from 'react';
import LoginPage from './LoginPage';
import './App.css';

function App() {
  return (
    <div className="App">
      <LoginPage />
    </div>
  );
}

export default App;