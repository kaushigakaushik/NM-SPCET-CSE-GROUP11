import React, { Component } from 'react';

class LoginPage extends Component {
  constructor() {
    super();
    this.state = {
      username: '',
      password: '',
    };
  }

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  handleLogin = () => {
    const { username, password } = this.state;
    // Perform your login logic here, e.g., making an API request
    console.log(`Username: ${username}, Password: ${password}`);
    // You can add your authentication logic here and redirect the user if successful
  }

  render() {
    return (
      <div className="login-page">
        <h2>Login</h2>
        <div>
          <label htmlFor="username">Username</label>
          <input
            type="text"
            name="username"
            value={this.state.username}
            onChange={this.handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            name="password"
            value={this.state.password}
            onChange={this.handleInputChange}
          />
        </div>
        <button onClick={this.handleLogin}>Login</button>
      </div>
    );
  }
}

export default LoginPage;
